-- Required for the YouTube OAuth integration.
-- Run after the existing social_signals migration.

ALTER TABLE public.social_signals
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

CREATE UNIQUE INDEX IF NOT EXISTS social_signals_user_app_unique
  ON public.social_signals(user_id, app_name);

CREATE UNIQUE INDEX IF NOT EXISTS app_connections_user_app_unique
  ON public.app_connections(user_id, app_name);
