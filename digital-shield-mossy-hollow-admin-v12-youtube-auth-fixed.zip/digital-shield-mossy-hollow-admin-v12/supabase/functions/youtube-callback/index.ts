const dec = (s: string) => atob(s.replace(/-/g,'+').replace(/_/g,'/') + '='.repeat((4-s.length%4)%4))
const enc = (s: string) => btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')
const hmac = async (secret: string, data: string) => {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), {name:'HMAC',hash:'SHA-256'}, false, ['sign'])
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(data))
  return enc(String.fromCharCode(...new Uint8Array(sig)))
}
const timingSafeEqual = (a:string,b:string) => a.length===b.length && [...a].every((c,i)=>c===b[i])

export default async (req: Request) => {
  const url = new URL(req.url)
  const code = url.searchParams.get('code')
  const state = url.searchParams.get('state') || ''
  const error = url.searchParams.get('error')
  const site = Deno.env.get('SITE_URL') || '/'
  if (error) return Response.redirect(`${site}/?oauth=youtube_denied`,302)
  if (!code || !state) return new Response('Invalid OAuth callback', {status:400})
  const [stateBody, signature] = state.split('.')
  const secret = Deno.env.get('OAUTH_STATE_SECRET')
  const clientId = Deno.env.get('GOOGLE_CLIENT_ID')
  const clientSecret = Deno.env.get('GOOGLE_CLIENT_SECRET')
  const redirect = Deno.env.get('YOUTUBE_REDIRECT_URI')
  if (!secret || !clientId || !clientSecret || !redirect) return new Response('OAuth is not configured', {status:503})
  const payload = dec(stateBody)
  const expected = await hmac(secret,payload)
  if (!timingSafeEqual(expected,signature)) return new Response('Invalid OAuth state', {status:400})
  const [userId, issued] = payload.split('.')
  if (!userId || Date.now()-Number(issued)>10*60*1000) return new Response('Expired OAuth state', {status:400})

  const tokenRes = await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({code,client_id:clientId,client_secret:clientSecret,redirect_uri:redirect,grant_type:'authorization_code'})})
  const tokens = await tokenRes.json()
  if (!tokenRes.ok || !tokens.access_token) return Response.redirect(`${site}/?oauth=youtube_error`,302)

  const api = `https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&mine=true`
  const channelRes = await fetch(api,{headers:{Authorization:`Bearer ${tokens.access_token}`}})
  const channel = await channelRes.json()
  if (!channelRes.ok || !channel.items?.length) return Response.redirect(`${site}/?oauth=youtube_no_channel`,302)
  const item = channel.items[0]
  const snippet = item.snippet || {}
  const stats = item.statistics || {}
  const signals = {
    public_profile: true,
    display_name_present: Boolean(snippet.title),
    description_present: Boolean(snippet.description),
    custom_thumbnail_present: Boolean(snippet.thumbnails),
    public_activity: Number(stats.videoCount||0)>0,
    public_subscriber_count: stats.hiddenSubscriberCount ? false : true,
    video_count: Number(stats.videoCount||0),
    view_count: Number(stats.viewCount||0),
    source_scope: 'youtube.readonly'
  }
  const supa = await import('npm:@supabase/supabase-js@2')
  const client = supa.createClient(Deno.env.get('SUPABASE_URL')!, JSON.parse(Deno.env.get('SUPABASE_SECRET_KEYS')!)['default'])
  await client.from('social_signals').upsert({user_id:userId,app_name:'YouTube',signals,source:'youtube_oauth',collected_at:new Date().toISOString()},{onConflict:'user_id,app_name'})
  await client.from('app_connections').upsert({user_id:userId,app_name:'YouTube',permission_status:'authorized',connected_at:new Date().toISOString()},{onConflict:'user_id,app_name'})
  return Response.redirect(`${site}/?oauth=youtube_success`,302)
}
