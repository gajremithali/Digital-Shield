import { withSupabase } from 'npm:@supabase/server'

const enc = (s: string) => btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')
const hmac = async (secret: string, data: string) => {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), {name:'HMAC',hash:'SHA-256'}, false, ['sign'])
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(data))
  return enc(String.fromCharCode(...new Uint8Array(sig)))
}

export default {
  fetch: withSupabase({ auth: 'user' }, async (req, ctx) => {
    if (req.method !== 'GET') return new Response('Method not allowed', {status:405})
    const clientId = Deno.env.get('GOOGLE_CLIENT_ID')
    const secret = Deno.env.get('OAUTH_STATE_SECRET')
    const redirect = Deno.env.get('YOUTUBE_REDIRECT_URI')
    if (!clientId || !secret || !redirect) return Response.json({error:'YouTube OAuth is not configured yet.'},{status:503})
    const uid = ctx.userClaims?.sub
    if (!uid) return Response.json({error:'Not authenticated'},{status:401})
    const payload = `${uid}.${Date.now()}.${crypto.randomUUID()}`
    const signature = await hmac(secret, payload)
    const state = `${enc(payload)}.${signature}`
    const params = new URLSearchParams({
      client_id: clientId,
      redirect_uri: redirect,
      response_type: 'code',
      access_type: 'online',
      prompt: 'consent',
      scope: 'https://www.googleapis.com/auth/youtube.readonly',
      state,
    })
    return Response.json({url:`https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`})
  })
}
